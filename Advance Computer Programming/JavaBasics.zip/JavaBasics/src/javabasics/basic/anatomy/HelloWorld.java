// HelloWorld.java - Basic example showing Java program anatomy
package javabasics.basic.anatomy;

/**
 * Example of a basic Java class with main method
 */
public class HelloWorld {
    // Main method - entry point for Java application
    public static void main(String[] args) {
        // Print statement outputs text to console
        System.out.println("Hello, World!");
    }
} 