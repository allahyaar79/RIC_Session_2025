// SimpleCompilation.java - Basic example for compilation demo
package javabasics.basic.compilation;

public class SimpleCompilation {
    public static void main(String[] args) {
        System.out.println("This program demonstrates basic Java compilation");
        System.out.println("Compile with: javac SimpleCompilation.java");
        System.out.println("Run with: java SimpleCompilation");
    }
} 